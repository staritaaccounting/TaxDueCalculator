# Tax Calculator — PWA shell

A thin installable PWA wrapper around your Apps Script web app
(`https://script.google.com/macros/s/AKfycbx2EgayzIDev9Uisfug65nCmc_XejpLoi2J3eUqtUo9npka8vhg0z1iXWFW_rs1eCfr/exec`),
loaded in a full-screen iframe with a branded splash screen and an
"Install" banner for both Android/Chrome and iOS Safari.

## Files
- `index.html` — shell page, splash screen, install banner, hardcoded app URL
- `manifest.json` — PWA metadata (name, icons, theme colors)
- `sw.js` — service worker (caches the shell for offline/fast reload)
- `icon.png` — app icon (512×512)
- `_nojekyll` — tells GitHub Pages not to run Jekyll on this repo (required so files like this one aren't mangled)

## Deploy to GitHub Pages
1. Create a new GitHub repo (or use an existing one).
2. Upload all 5 files above to the **root** of the repo (or to a `/docs` folder — just make sure Pages is set to serve from wherever you put them).
3. Go to **Settings → Pages**, set **Source** to the branch/folder containing these files, and save.
4. Wait a minute for the first deploy, then open the `https://<username>.github.io/<repo>/` URL GitHub gives you.
5. Visit it on your phone — Chrome/Edge on Android will show the install banner automatically after a few seconds; on iOS Safari the banner tells you to tap Share → **Add to Home Screen** (iOS doesn't allow apps to trigger the install prompt directly, so this is the standard workaround).

## Updating the app URL later
Open `index.html` and change the `APP_URL` value near the top of the `<script>` block — nothing else needs to change.

## Notes
- The service worker only caches the shell files listed above (same-origin). It does **not** cache anything from the Apps Script app itself, so your live data always loads fresh from Google.
- The install banner remembers "Not now" for 14 days (per device) before showing again, and won't show at all once the app is actually installed (`display-mode: standalone`).
